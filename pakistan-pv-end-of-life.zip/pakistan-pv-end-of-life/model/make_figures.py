"""Figures for the manuscript. Reads ../outputs CSVs written by pv_eol_model.py."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "outputs")
FIG = os.path.join(HERE, "..", "figures")
os.makedirs(FIG, exist_ok=True)

# Validated categorical palette (light): blue, orange, aqua, yellow
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#ffffff"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "figure.facecolor": SURF, "axes.facecolor": SURF, "legend.frameon": False, "savefig.dpi": 600,
})
SCEN = ["Regular-loss, T=30 y", "Early-loss, T=30 y", "Early-loss, T=25 y", "Early-loss, T=20 y"]


def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".pdf"), bbox_inches="tight")
    plt.close(fig)


# Figure 1: cohort structure
coh = pd.read_csv(os.path.join(OUT, "table_cohorts.csv"))
fig, ax = plt.subplots(figsize=(3.5, 2.6))
bars = ax.bar(coh.cohort, coh.GW, color=C[0], width=0.72, edgecolor=SURF, linewidth=1.0)
for b, v in zip(bars, coh.GW):
    ax.text(b.get_x() + b.get_width() / 2, v + 0.3, f"{v:.1f}", ha="center", va="bottom", fontsize=7, color=INK)
ax.set_ylabel("Capacity added (GW$_{DC}$)")
ax.set_xlabel("Installation cohort (Pakistani fiscal year)")
ax.tick_params(axis="x", rotation=45)
ax.set_ylim(0, 16.5)
ax.grid(axis="x", visible=False)
save(fig, "Figure1_cohorts")

# Figure 2: annual and cumulative EoL (two panels, one axis each)
s = pd.read_csv(os.path.join(OUT, "series_eol_annual.csv"))
T_PER_GW = 1e9 / 19.1 / 1000
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.8))
for i, name in enumerate(SCEN):
    axs[0].plot(s.year, s[name + " annual GW"] * T_PER_GW / 1000, color=C[i], lw=2, label=name)
    axs[1].plot(s.year, s[name + " cumulative GW"], color=C[i], lw=2, label=name)
axs[0].set_ylabel("End-of-life modules (kt per year)")
axs[1].set_ylabel("Cumulative end-of-life capacity (GW)")
axs[1].axhline(51.0, color=INK2, lw=0.8, ls="--")
axs[1].text(2027, 52.2, "Installed fleet, Mar 2026 (51 GW)", fontsize=6.5, color=INK2)
for ax, lab in zip(axs, ["A", "B"]):
    ax.set_xlabel("Year")
    ax.set_xlim(2026, 2060)
    ax.text(-0.14, 1.02, lab, transform=ax.transAxes, fontsize=10, fontweight="bold")
axs[1].legend(loc="upper left", bbox_to_anchor=(0.0, 0.93), fontsize=6.5)
axs[1].set_ylim(0, 56)
fig.tight_layout()
save(fig, "Figure2_eol_trajectories")

# Figure 3: effective capacity share under failure x degradation
e = pd.read_csv(os.path.join(OUT, "table_effective_capacity.csv"))
degs = e.degradation.unique()
fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.6), sharey=True)
for j, dname in enumerate(degs):
    ax = axs[j]
    for i, name in enumerate(SCEN):
        d = e[(e.failure_scenario == name) & (e.degradation == dname)]
        ax.plot(d.year, d.effective_GW, color=C[i], lw=2, marker="o", ms=4, label=name)
    ax.set_title(dname, fontsize=7.5, color=INK)
    ax.set_xticks([2026, 2030, 2035, 2040])
    ax.set_xlabel("Year (1 January)")
    ax.text(-0.12 if j == 0 else -0.05, 1.08, "ABC"[j], transform=ax.transAxes, fontsize=10, fontweight="bold")
axs[0].set_ylabel("Effective capacity (GW, of 51 GW nameplate)")
axs[0].set_ylim(20, 52)
axs[0].legend(loc="lower left", fontsize=6)
fig.tight_layout()
save(fig, "Figure3_effective_capacity")

# Figure 4: sensitivity (tornado) on cumulative EoL mass to end-2040
t = pd.read_csv(os.path.join(OUT, "table_sensitivity_2040.csv"))
base = t.base_kt.iloc[0]
t["lo"] = t[["low_case_kt", "high_case_kt"]].min(axis=1)
t["hi"] = t[["low_case_kt", "high_case_kt"]].max(axis=1)
t["span"] = t.hi - t.lo
t = t.sort_values("span")
fig, ax = plt.subplots(figsize=(4.6, 2.2))
y = np.arange(len(t))
ax.barh(y, t.hi - t.lo, left=t.lo, color=C[0], height=0.55, edgecolor=SURF)
for yi, lo, hi in zip(y, t.lo, t.hi):
    ax.text(lo - 15, yi, f"{lo:.0f}", ha="right", va="center", fontsize=6.5, color=INK)
    ax.text(hi + 15, yi, f"{hi:.0f}", ha="left", va="center", fontsize=6.5, color=INK)
ax.axvline(base, color=INK, lw=1)
ax.text(base, len(t) - 0.35, f"central {base:.0f} kt", ha="center", fontsize=6.5, color=INK)
ax.set_yticks(y)
ax.set_yticklabels(t.parameter, fontsize=7)
ax.set_xlabel("Cumulative end-of-life mass by end-2040 (kt)")
ax.set_xlim(200, 1300)
ax.grid(axis="y", visible=False)
save(fig, "Figure4_sensitivity")
print("figures written:", sorted(os.listdir(FIG)))
