"""
End-of-life and performance-loss model for Pakistan's distributed PV fleet
(cohorts installed FY2018 - 9M FY2026, i.e. through March 2026).

Every input below is taken from a cited public source (see INPUTS dict and the
manuscript Methods). Outputs are written to ../outputs as CSV files and figures.
Run:  python3 pv_eol_model.py
"""
import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "outputs")
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------------------
# 1. Installation cohorts (GW, DC) and their mid-point installation dates
# ---------------------------------------------------------------------------
# Anchors (Renewables First / Ember):
#   stock end-FY22 = 7.7 GW (7.0 GW BTM/off-grid + 0.7 GW net-metered)  [PER26]
#   stock end-FY23 = 38.0 - 27.0 = 11.0 GW                               [Ember 2026]
#   stock end-FY25 = 38.0 GW                                             [PER26, Ember 2026]
#   stock end-Mar-2026 = 51.0 GW                                         [PER26]
# FY24/FY25 split of the 27.0 GW two-year addition follows fiscal-year module
# imports: FY24 16.0 GW, FY25 17.9 GW                                    [RF PER25, RF 2025]
STOCK_FY22 = 7.7
STOCK_FY23 = 11.0
STOCK_FY25 = 38.0
STOCK_MAR26 = 51.0
IMP_FY24, IMP_FY25 = 16.0, 17.9

add_2yr = STOCK_FY25 - STOCK_FY23
add_fy24 = add_2yr * IMP_FY24 / (IMP_FY24 + IMP_FY25)
add_fy25 = add_2yr - add_fy24

cohorts = pd.DataFrame(
    {
        "cohort": ["FY18", "FY19", "FY20", "FY21", "FY22", "FY23", "FY24", "FY25", "FY26 (9M)"],
        # mid-point of each fiscal year (Jul-Jun); FY26 covers Jul 2025-Mar 2026
        "t_install": [2018.0, 2019.0, 2020.0, 2021.0, 2022.0, 2023.0, 2024.0, 2025.0, 2025.875],
        "GW": [STOCK_FY22 / 5] * 5
        + [STOCK_FY23 - STOCK_FY22, add_fy24, add_fy25, STOCK_MAR26 - STOCK_FY25],
    }
)
assert abs(cohorts.GW.sum() - STOCK_MAR26) < 1e-9

# ---------------------------------------------------------------------------
# 2. Parameters
# ---------------------------------------------------------------------------
WEIBULL = {  # IRENA & IEA-PVPS (2016), T12-06:2016, Table 5 and Table 4
    "Regular-loss, T=30 y": (5.3759, 30.0),
    "Early-loss, T=30 y": (2.4928, 30.0),
    "Early-loss, T=25 y": (2.4928, 25.0),
    "Early-loss, T=20 y": (2.4928, 20.0),
}
DEGRADATION = {  # %/y power-loss rate
    "0.50 %/y (global median)": 0.0050,  # Jordan & Kurtz 2013; Jordan et al. 2016
    "0.88 %/y (hot-climate fleet median)": 0.0088,  # Jordan et al. 2022
    "1.50 %/y (stress test)": 0.0150,  # assumption, upper-tail stress case
}
CF = 0.1671  # capacity factor, Renewables First estimate reported by Ember (2026)
YIELD_KWH_PER_KW = CF * 8760  # = 1463.8 kWh/kW/y
SPEC_POWER_W_PER_KG = 19.1  # median 2020-2024 c-Si products, Bolson & Iqbal 2026
T_PER_GW = 1e9 / SPEC_POWER_W_PER_KG / 1000.0  # tonnes per GW = 52,356
COMPOSITION = {  # mass shares of c-Si modules, IRENA & IEA-PVPS 2016
    "Glass": 0.76, "Polymers": 0.10, "Aluminium": 0.08, "Silicon": 0.05, "Copper": 0.01,
}
AG_MG_PER_W = 7244e9 / 706e9  # ITRPV 17th ed.: 7,244 t Ag for 706 GW shipped in 2025 (mg/W)
GRID_SALES_FY25_TWH = 111.0  # Renewables First PER26
DG_GEN_FY25_TWH = 51.0  # Renewables First PER26
DEPLOY_ALT = {"TransitionZero (27.5 GW)": 27.5 / 38.0, "PRIED (33 GW)": 33.0 / 38.0}

YEARS = np.arange(2026, 2061)


def weibull_cdf(age, alpha, T):
    age = np.clip(age, 0, None)
    return 1.0 - np.exp(-((age / T) ** alpha))


def eol_by_year(alpha, T, scale=1.0, years=YEARS):
    """Capacity (GW) reaching end of life in each calendar year y (age from y to y+1).
    Losses already incurred before 1 Jan 2026 are reported separately."""
    out = np.zeros(len(years))
    for _, c in cohorts.iterrows():
        a0 = years - c.t_install
        a1 = years + 1 - c.t_install
        out += scale * c.GW * (weibull_cdf(a1, alpha, T) - weibull_cdf(a0, alpha, T))
    return out


def eol_before_2026(alpha, T):
    return sum(c.GW * weibull_cdf(2026 - c.t_install, alpha, T) for _, c in cohorts.iterrows())


def effective_capacity(alpha, T, d, year):
    """Surviving, degraded capacity (GW) at 1 Jan of `year`."""
    tot = 0.0
    for _, c in cohorts.iterrows():
        age = max(year - c.t_install, 0)
        tot += c.GW * (1 - weibull_cdf(age, alpha, T)) * (1 - d) ** age
    return tot


# ---------------------------------------------------------------------------
# 3. Runs
# ---------------------------------------------------------------------------
results = {}
rows = []
for name, (a, T) in WEIBULL.items():
    ann = eol_by_year(a, T)
    pre = eol_before_2026(a, T)
    cum = pre + np.cumsum(ann)
    results[name] = {"annual_GW": ann, "cum_GW": cum, "pre2026_GW": pre}
    for y in (2030, 2035, 2040, 2045, 2050):
        i = int(np.where(YEARS == y)[0][0])
        rows.append(
            {
                "scenario": name,
                "year_end": y,
                "cumulative_EoL_GW": cum[i],
                "cumulative_EoL_share_of_fleet": cum[i] / STOCK_MAR26,
                "cumulative_EoL_kt": cum[i] * T_PER_GW / 1000,
                "annual_EoL_GW_in_year": ann[i],
                "annual_EoL_kt_in_year": ann[i] * T_PER_GW / 1000,
            }
        )
    peak_i = int(np.argmax(ann))
    rows.append({"scenario": name, "year_end": "peak", "annual_EoL_GW_in_year": ann[peak_i],
                 "annual_EoL_kt_in_year": ann[peak_i] * T_PER_GW / 1000, "peak_year": int(YEARS[peak_i])})
tab_eol = pd.DataFrame(rows)
tab_eol.to_csv(os.path.join(OUT, "table_eol_scenarios.csv"), index=False)

# Year at which half the fleet (by GW) has reached end of life
half = {}
for name, r in results.items():
    idx = np.where(r["cum_GW"] >= STOCK_MAR26 / 2)[0]
    half[name] = int(YEARS[idx[0]]) if len(idx) else None

# Materials for the whole 51 GW fleet (embedded mass)
fleet_t = STOCK_MAR26 * T_PER_GW
materials = {k: v * fleet_t for k, v in COMPOSITION.items()}
materials["Silver"] = STOCK_MAR26 * 1e9 * AG_MG_PER_W / 1e9  # tonnes (mg/W * W / 1e9)

# Effective capacity and lost generation
eff_rows = []
for sname, (a, T) in WEIBULL.items():
    for dname, d in DEGRADATION.items():
        for y in (2026, 2030, 2035, 2040):
            ec = effective_capacity(a, T, d, y)
            lost_gw = STOCK_MAR26 - ec
            lost_twh = lost_gw * YIELD_KWH_PER_KW / 1000  # GW * kWh/kW = GWh ; /1000 -> TWh
            eff_rows.append(
                {
                    "failure_scenario": sname,
                    "degradation": dname,
                    "year": y,
                    "effective_GW": ec,
                    "effective_share": ec / STOCK_MAR26,
                    "lost_GW_equiv": lost_gw,
                    "lost_TWh_per_y": lost_twh,
                    "lost_share_of_FY25_grid_sales": lost_twh / GRID_SALES_FY25_TWH,
                }
            )
tab_eff = pd.DataFrame(eff_rows)
tab_eff.to_csv(os.path.join(OUT, "table_effective_capacity.csv"), index=False)

# Replacement need: GW of new modules per year to hold effective capacity constant
rep_rows = []
for sname, (a, T) in WEIBULL.items():
    for dname, d in DEGRADATION.items():
        ec = np.array([effective_capacity(a, T, d, y) for y in range(2026, 2042)])
        need = -np.diff(ec)  # GW of effective capacity lost per year
        rep_rows.append({"failure_scenario": sname, "degradation": dname,
                         "mean_GW_per_y_2026_2035": need[:10].mean(),
                         "mean_GW_per_y_2036_2040": need[10:15].mean()})
tab_rep = pd.DataFrame(rep_rows)
tab_rep.to_csv(os.path.join(OUT, "table_replacement_need.csv"), index=False)

# One-at-a-time sensitivity on cumulative EoL mass by end-2040 (central: Early-loss T=25)
a_c, T_c = WEIBULL["Early-loss, T=25 y"]
base_2040 = eol_before_2026(a_c, T_c) + eol_by_year(a_c, T_c)[YEARS <= 2040].sum()
sens = []


def cum2040(alpha=a_c, T=T_c, scale=1.0, tpgw=T_PER_GW):
    gw = scale * eol_before_2026(alpha, T) + eol_by_year(alpha, T, scale)[YEARS <= 2040].sum()
    return gw * tpgw / 1000  # kt


base_kt = cum2040()
sens.append(("Mean lifetime T (20 / 30 y)", cum2040(T=20.0), cum2040(T=30.0)))
sens.append(("Weibull shape (early / regular loss)", cum2040(alpha=2.4928), cum2040(alpha=5.3759)))
sens.append(("Deployed stock (TransitionZero / imports 54 GW)",
             cum2040(scale=27.5 / 38.0), cum2040(scale=54.0 / 51.0)))
sens.append(("Specific power (19.1 / 14.5 W/kg)",
             cum2040(), cum2040(tpgw=1e9 / (270 / 18.6) / 1000)))  # IRENA 2016 example: 270 Wp, 18.6 kg
tab_sens = pd.DataFrame(sens, columns=["parameter", "low_case_kt", "high_case_kt"])
tab_sens["base_kt"] = base_kt
tab_sens.to_csv(os.path.join(OUT, "table_sensitivity_2040.csv"), index=False)

cohorts.assign(share=cohorts.GW / STOCK_MAR26).to_csv(os.path.join(OUT, "table_cohorts.csv"), index=False)

summary = {
    "cohorts": cohorts.to_dict(orient="list"),
    "add_fy24": add_fy24, "add_fy25": add_fy25,
    "yield_kWh_per_kW": YIELD_KWH_PER_KW,
    "t_per_GW": T_PER_GW,
    "fleet_mass_kt": fleet_t / 1000,
    "materials_t": materials,
    "Ag_mg_per_W": AG_MG_PER_W,
    "half_fleet_year": half,
    "pre2026_EoL_GW": {k: v["pre2026_GW"] for k, v in results.items()},
    "sensitivity_base_kt_2040": base_kt,
}
with open(os.path.join(OUT, "summary.json"), "w") as f:
    json.dump(summary, f, indent=2, default=float)

# Annual series for figures
ann_df = pd.DataFrame({"year": YEARS})
for name, r in results.items():
    ann_df[name + " annual GW"] = r["annual_GW"]
    ann_df[name + " cumulative GW"] = r["cum_GW"]
ann_df.to_csv(os.path.join(OUT, "series_eol_annual.csv"), index=False)

print(json.dumps(summary, indent=2, default=float))
print(tab_eol.to_string())
print(tab_eff[tab_eff.year.isin([2035, 2040])].to_string())
print(tab_rep.to_string())
print(tab_sens.to_string())
